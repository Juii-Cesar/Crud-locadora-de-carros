<?php
include("conexao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locadora de Carros</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="container"> 
        <h1>Menu</h1>
        <nav class="nav">
            <a href="cadastrarCliente.php">Cadastro de Cliente</a>
            <a href="cadastrarCarro.php">Cadastro de Carro</a>
            <a href="cadastrarAluguel.php">Aluguel</a>
            <a href="consultarCliente.html">Consultar clientes</a>
        </nav>
    </div>
    
</body>
</html>
